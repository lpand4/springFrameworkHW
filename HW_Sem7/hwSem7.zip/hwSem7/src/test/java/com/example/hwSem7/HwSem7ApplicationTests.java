package com.example.hwSem7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HwSem7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
