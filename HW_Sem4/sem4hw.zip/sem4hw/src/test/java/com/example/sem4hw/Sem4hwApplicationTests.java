package com.example.sem4hw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sem4hwApplicationTests {

	@Test
	void contextLoads() {
	}

}
